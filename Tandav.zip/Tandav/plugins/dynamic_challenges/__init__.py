from flask import Blueprint

from Tandav.exceptions.challenges import (
    ChallengeCreateException,
    ChallengeUpdateException,
)
from Tandav.models import Challenges, db
from Tandav.plugins import register_plugin_assets_directory
from Tandav.plugins.challenges import CHALLENGE_CLASSES, BaseChallenge
from Tandav.plugins.dynamic_challenges.decay import DECAY_FUNCTIONS, logarithmic
from Tandav.plugins.migrations import upgrade
from Tandav.utils.dates import parse_iso_datetime


class DynamicChallenge(Challenges):
    __mapper_args__ = {"polymorphic_identity": "dynamic"}
    id = db.Column(
        db.Integer, db.ForeignKey("challenges.id", ondelete="CASCADE"), primary_key=True
    )
    dynamic_initial = db.Column(db.Integer, default=0)
    dynamic_minimum = db.Column(db.Integer, default=0)
    dynamic_decay = db.Column(db.Integer, default=0)
    dynamic_function = db.Column(db.String(32), default="logarithmic")

    @property
    def initial(self):
        return self.dynamic_initial

    @initial.setter
    def initial(self, initial_value):
        self.dynamic_initial = initial_value

    @property
    def minimum(self):
        return self.dynamic_minimum

    @minimum.setter
    def minimum(self, minimum_value):
        self.dynamic_minimum = minimum_value

    @property
    def decay(self):
        return self.dynamic_decay

    @decay.setter
    def decay(self, decay_value):
        self.dynamic_decay = decay_value

    @property
    def function(self):
        return self.dynamic_function

    @function.setter
    def function(self, function_value):
        self.dynamic_function = function_value

    def __init__(self, *args, **kwargs):
        super(DynamicChallenge, self).__init__(**kwargs)
        try:
            self.value = kwargs["initial"]
        except KeyError:
            raise ChallengeCreateException("Missing initial value for challenge")


class DynamicValueChallenge(BaseChallenge):
    id = "dynamic"  # Unique identifier used to register challenges
    name = "dynamic"  # Name of a challenge type
    templates = {  # Handlebars templates used for each aspect of challenge editing & viewing
        "create": "/plugins/dynamic_challenges/assets/create.html",
        "update": "/plugins/dynamic_challenges/assets/update.html",
        "view": "/plugins/dynamic_challenges/assets/view.html",
    }
    scripts = {  # Scripts that are loaded when a template is loaded
        "create": "/plugins/dynamic_challenges/assets/create.js",
        "update": "/plugins/dynamic_challenges/assets/update.js",
        "view": "/plugins/dynamic_challenges/assets/view.js",
    }
    # Route at which files are accessible. This must be registered using register_plugin_assets_directory()
    route = "/plugins/dynamic_challenges/assets/"
    # Blueprint used to access the static_folder directory.
    blueprint = Blueprint(
        "dynamic_challenges",
        __name__,
        template_folder="templates",
        static_folder="assets",
    )
    challenge_model = DynamicChallenge

    @classmethod
    def calculate_value(cls, challenge):
        f = DECAY_FUNCTIONS.get(challenge.function, logarithmic)
        value = f(challenge)

        challenge.value = value
        db.session.commit()
        return challenge

    @classmethod
    def read(cls, challenge):
        """
        This method is in used to access the data of a challenge in a format processable by the front end.

        :param challenge:
        :return: Challenge object, data dictionary to be returned to the user
        """
        challenge = DynamicChallenge.query.filter_by(id=challenge.id).first()
        data = super().read(challenge)
        data.update(
            {
                "initial": challenge.initial,
                "decay": challenge.decay,
                "minimum": challenge.minimum,
                "function": challenge.function,
            }
        )
        return data

    @classmethod
    def update(cls, challenge, request):
        """
        This method is used to update the information associated with a challenge. This should be kept strictly to the
        Challenges table and any child tables.

        :param challenge:
        :param request:
        :return:
        """
        data = dict(request.form or request.get_json() or {})
        if "scheduled_at" in data:
            try:
                data["scheduled_at"] = parse_iso_datetime(data["scheduled_at"])
            except ValueError:
                raise ChallengeUpdateException("Invalid input for 'scheduled_at'")

        for attr, value in data.items():
            # We need to set these to floats so that the next operations don't operate on strings
            if attr in ("initial", "minimum", "decay"):
                try:
                    value = float(value)
                except (ValueError, TypeError):
                    raise ChallengeUpdateException(f"Invalid input for '{attr}'")
            setattr(challenge, attr, value)

        return DynamicValueChallenge.calculate_value(challenge)

    @classmethod
    def solve(cls, user, team, challenge, request):
        super().solve(user, team, challenge, request)

        DynamicValueChallenge.calculate_value(challenge)


def load(app):
    upgrade(plugin_name="dynamic_challenges")
    CHALLENGE_CLASSES["dynamic"] = DynamicValueChallenge
    register_plugin_assets_directory(
        app, base_path="/plugins/dynamic_challenges/assets/"
    )
