Tandav._internal.challenge.data = undefined;

// TODO: Remove in Tandav v4.0
Tandav._internal.challenge.renderer = null;

Tandav._internal.challenge.preRender = function() {};

// TODO: Remove in Tandav v4.0
Tandav._internal.challenge.render = null;

Tandav._internal.challenge.postRender = function() {};

Tandav._internal.challenge.submit = function(preview) {
  var challenge_id = parseInt(Tandav.lib.$("#challenge-id").val());
  var submission = Tandav.lib.$("#challenge-input").val();

  var body = {
    challenge_id: challenge_id,
    submission: submission
  };
  var params = {};
  if (preview) {
    params["preview"] = true;
  }

  return Tandav.api.post_challenge_attempt(params, body).then(function(response) {
    if (response.status === 429) {
      // User was ratelimited but process response
      return response;
    }
    if (response.status === 403) {
      // User is not logged in or CTF is paused.
      return response;
    }
    return response;
  });
};
