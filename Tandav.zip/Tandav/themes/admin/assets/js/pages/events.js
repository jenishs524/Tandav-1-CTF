import $ from "jquery";
import events from "../compat/events";
import Tandav from "../../compat/Tandav";

$(() => {
  events(Tandav.config.urlRoot);
});
