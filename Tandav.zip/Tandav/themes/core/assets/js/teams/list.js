import Alpine from "alpinejs";
import Tandav from "../index";

window.Tandav = Tandav;
window.Alpine = Alpine;

Alpine.start();
