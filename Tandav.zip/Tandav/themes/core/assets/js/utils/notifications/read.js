import Alpine from "alpinejs";
import Tandav from "../../index";

export default () => {
  Tandav._functions.events.eventCount = count => {
    Alpine.store("unread_count", count);
  };

  Tandav._functions.events.eventRead = eventId => {
    Tandav.events.counter.read.add(eventId);
    let count = Tandav.events.counter.unread.getAll().length;
    Tandav.events.controller.broadcast("counter", { count: count });
    Alpine.store("unread_count", count);
  };

  document.addEventListener("alpine:init", () => {
    Tandav._functions.events.eventCount(Tandav.events.counter.unread.getAll().length);
  });
};
