import{C as o,m as d}from"./index.0eace8c9.js";window.Tandav=o;window.Alpine=d;d.start();
