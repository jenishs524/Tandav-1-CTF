import hashlib
import base64
import os
import hmac

from passlib.hash import bcrypt_sha256
from nacl import pwhash
from nacl.exceptions import InvalidkeyError
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from sqlalchemy.types import Text, TypeDecorator

def hash_password(plaintext):
    return pwhash.argon2id.str(str(plaintext).encode("utf-8")).decode("utf-8")


def verify_password(plaintext, ciphertext):
    if isinstance(ciphertext, str) and ciphertext.startswith("$argon2"):
        try:
            pwhash.argon2id.verify(
                ciphertext.encode("utf-8"), str(plaintext).encode("utf-8")
            )
            return True
        except (InvalidkeyError, ValueError):
            return False
    return bcrypt_sha256.verify(plaintext, ciphertext)


def sha256(p):
    if isinstance(p, str):
        p = p.encode("utf-8")
    return hashlib.sha256(p).hexdigest()


def _aesgcm_key():
    value = os.getenv("PII_ENCRYPTION_KEY")
    if not value:
        return None
    try:
        key = base64.b64decode(value)
    except Exception:
        raise RuntimeError("PII_ENCRYPTION_KEY must be base64 encoded")
    if len(key) != 32:
        raise RuntimeError("PII_ENCRYPTION_KEY must encode exactly 32 bytes for AES-256")
    return key


def encrypt_sensitive(value):
    key = _aesgcm_key()
    if key is None:
        raise RuntimeError("PII_ENCRYPTION_KEY is not configured")
    if value is None:
        return None
    if not isinstance(value, bytes):
        value = str(value).encode("utf-8")
    nonce = os.urandom(12)
    ciphertext = AESGCM(key).encrypt(nonce, value, None)
    return "v1:" + base64.b64encode(nonce + ciphertext).decode("ascii")


def decrypt_sensitive(value):
    if value is None:
        return None
    if not value.startswith("v1:"):
        raise RuntimeError("Unsupported sensitive-data ciphertext version")
    blob = base64.b64decode(value[3:])
    keys = [_aesgcm_key()]
    previous = os.getenv("PII_ENCRYPTION_KEY_PREVIOUS")
    if previous:
        try:
            keys.append(base64.b64decode(previous))
        except Exception:
            raise RuntimeError("PII_ENCRYPTION_KEY_PREVIOUS must be base64 encoded")
    for key in keys:
        if key is None:
            continue
        try:
            plaintext = AESGCM(key).decrypt(blob[:12], blob[12:], None)
            return plaintext.decode("utf-8")
        except Exception:
            continue
    raise RuntimeError("Unable to decrypt PII with configured keys")


def pii_search_index(value):
    key = os.getenv("PII_SEARCH_KEY")
    if not key:
        raise RuntimeError("PII_SEARCH_KEY is not configured")
    try:
        raw_key = base64.b64decode(key)
    except Exception:
        raise RuntimeError("PII_SEARCH_KEY must be base64 encoded")
    if len(raw_key) != 32:
        raise RuntimeError("PII_SEARCH_KEY must encode exactly 32 bytes")
    normalized = str(value).strip().lower().encode("utf-8")
    return hmac.new(raw_key, normalized, hashlib.sha256).hexdigest()


class EncryptedPIIText(TypeDecorator):
    impl = Text
    cache_ok = True

    @property
    def python_type(self):
        return str

    def process_bind_param(self, value, dialect):
        if value is None:
            return None
        if isinstance(value, str) and value.startswith("v1:"):
            return value
        return encrypt_sensitive(value)

    def process_result_value(self, value, dialect):
        if value is None:
            return None
        if not isinstance(value, str) or not value.startswith("v1:"):
            # Compatibility read for records created before staged encryption.
            return value
        return decrypt_sensitive(value)
