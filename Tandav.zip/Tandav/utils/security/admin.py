from functools import wraps
import time

from flask import abort, redirect, request, session, url_for

from Tandav.utils.user import is_admin


DEFAULT_ADMIN_PERMISSIONS = frozenset(
    {"challenges.manage", "users.manage", "submissions.manage", "config.manage"}
)

ENDPOINT_PERMISSION_MAP = {
    "admin.users": "users.manage",
    "admin.challenges": "challenges.manage",
    "admin.submissions": "submissions.manage",
    "admin.config": "config.manage",
    "admin.import": "config.manage",
    "admin.export": "config.manage",
    "admin.reset": "config.manage",
    "admin.teams": "users.manage",
    "admin.notifications": "config.manage",
    "admin.pages": "pages.manage",
    "admin.modules": "challenges.manage",
    "admin.audiences": "users.manage",
    "api.flags": "challenges.manage",
    "api.submissions": "submissions.manage",
    "api.users": "users.manage",
    "api.teams": "users.manage",
    "api.configs": "config.manage",
    "api.files": "uploads.manage",
    "api.challenges": "challenges.manage",
    "api.hints": "challenges.manage",
    "api.tags": "challenges.manage",
    "api.topics": "challenges.manage",
    "api.brackets": "users.manage",
    "api.audiences": "users.manage",
    "api.awards": "users.manage",
    "api.comments": "config.manage",
    "api.modules": "challenges.manage",
    "api.notifications": "config.manage",
    "api.pages": "pages.manage",
    "api.solutions": "challenges.manage",
    "api.unlocks": "challenges.manage",
    "api.scoreboard": "config.manage",
    "api.statistics": "config.manage",
    "api.exports": "config.manage",
    "api.tokens": "users.manage",
}


def audit_admin_action(action, target_type=None, target_id=None, outcome="success", metadata=None):
    from Tandav.models import SecurityAuditEvents, db
    from Tandav.utils.user import get_current_user, get_ip

    actor = get_current_user() if is_admin() else None
    event = SecurityAuditEvents(
        actor_user_id=actor.id if actor else None,
        action=str(action)[:128],
        target_type=str(target_type)[:64] if target_type else None,
        target_id=str(target_id)[:128] if target_id is not None else None,
        ip=get_ip(),
        outcome=str(outcome)[:32],
        metadata_json=metadata if metadata is not None else None,
    )
    db.session.add(event)
    db.session.commit()


def has_admin_permission(permission):
    if not is_admin():
        return False
    from Tandav.utils.user import get_current_user_attrs

    permissions = get_current_user_attrs().admin_permissions
    if permissions is None:
        return True
    return permission in permissions


def require_admin_permission(permission):
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            if not has_admin_permission(permission):
                abort(403)
            return f(*args, **kwargs)

        return wrapper

    return decorator


def require_admin_reauthentication(max_age_seconds=900):
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            if not is_admin():
                abort(403)
            authenticated_at = session.get("admin_reauthenticated_at")
            if (
                authenticated_at is None
                or time.time() - float(authenticated_at) > max_age_seconds
            ):
                if request.is_json:
                    abort(403, description="Recent administrator authentication required")
                return redirect(url_for("auth.mfa"))
            return f(*args, **kwargs)

        return wrapper

    return decorator


def require_admin_mfa(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not is_admin():
            if request.is_json:
                abort(403)
            return redirect(url_for("auth.login"))
        from Tandav.utils.user import get_current_user_attrs

        if not get_current_user_attrs().mfa_enabled:
            abort(403, description="Administrator MFA enrollment required")
        if not session.get("admin_mfa_verified"):
            if request.is_json:
                abort(403, description="Administrator MFA required")
            return redirect(url_for("auth.login"))
        return f(*args, **kwargs)

    return wrapper
