import base64
import hashlib
import hmac
import secrets
import struct
import time
import os
import base64

from cryptography.hazmat.primitives.ciphers.aead import AESGCM


def generate_totp_secret():
    return base64.b32encode(secrets.token_bytes(20)).decode("ascii").rstrip("=")


def verify_totp(secret, code, window=1):
    secret = secret.rstrip("=").upper()
    padded = secret + "=" * ((8 - len(secret) % 8) % 8)
    try:
        key = base64.b32decode(padded)
    except Exception:
        return False

    code = "".join(str(code).split())
    if not code.isdigit() or len(code) != 6:
        return False

    counter = int(time.time()) // 30
    for offset in range(-window, window + 1):
        msg = struct.pack(">Q", counter + offset)
        digest = hmac.new(key, msg, hashlib.sha1).digest()
        offset_byte = digest[-1] & 0x0F
        value = struct.unpack(">I", digest[offset_byte : offset_byte + 4])[0] & 0x7FFFFFFF
        candidate = str(value % 1000000).zfill(6)
        if hmac.compare_digest(candidate, code):
            return True
    return False


def generate_recovery_codes(count=10):
    return [secrets.token_urlsafe(10) for _ in range(count)]


def hash_recovery_code(code):
    return hashlib.sha256(code.encode("utf-8")).hexdigest()


def encrypt_secret(secret):
    key = os.getenv("MFA_ENCRYPTION_KEY")
    if not key:
        raise RuntimeError("MFA_ENCRYPTION_KEY is not configured")
    raw_key = base64.b64decode(key)
    if len(raw_key) != 32:
        raise RuntimeError("MFA_ENCRYPTION_KEY must encode exactly 32 bytes")
    nonce = os.urandom(12)
    ciphertext = AESGCM(raw_key).encrypt(nonce, secret.encode("utf-8"), None)
    return "v1:" + base64.b64encode(nonce + ciphertext).decode("ascii")


def decrypt_secret(value):
    key = os.getenv("MFA_ENCRYPTION_KEY")
    if not key:
        raise RuntimeError("MFA_ENCRYPTION_KEY is not configured")
    raw_key = base64.b64decode(key)
    if len(raw_key) != 32:
        raise RuntimeError("MFA_ENCRYPTION_KEY must encode exactly 32 bytes")
    if not value or not value.startswith("v1:"):
        raise RuntimeError("Unsupported MFA secret ciphertext")
    blob = base64.b64decode(value[3:])
    return AESGCM(raw_key).decrypt(blob[:12], blob[12:], None).decode("utf-8")
