from typing import List

from flask import abort, request
from flask_restx import Namespace, Resource

from Tandav.api.v1.helpers.request import validate_args
from Tandav.api.v1.helpers.schemas import sqlalchemy_to_pydantic
from Tandav.api.v1.schemas import APIDetailedSuccessResponse, APIListSuccessResponse
from Tandav.cache import cache, clear_standings
from Tandav.constants import RawEnum
from Tandav.models import (
    Challenges,
    Hints,
    HintUnlocks,
    Unlocks,
    db,
    get_class_by_tablename,
)
from Tandav.schemas.awards import AwardSchema
from Tandav.schemas.unlocks import UnlockSchema
from Tandav.utils.challenges import get_solve_ids_for_user_id
from Tandav.utils.config import is_teams_mode
from Tandav.utils.decorators import (
    admins_only,
    authed_only,
    during_ctf_time_only,
    require_verified_emails,
)
from Tandav.utils.decorators.visibility import check_challenge_visibility
from Tandav.utils.helpers.models import build_model_filters
from Tandav.utils.modules import can_access_challenge
from Tandav.utils.user import get_current_user, get_ip, is_admin

unlocks_namespace = Namespace("unlocks", description="Endpoint to retrieve Unlocks")

UnlockModel = sqlalchemy_to_pydantic(Unlocks)
TransientUnlockModel = sqlalchemy_to_pydantic(Unlocks, exclude=["id"])


class UnlockDetailedSuccessResponse(APIDetailedSuccessResponse):
    data: UnlockModel


class UnlockListSuccessResponse(APIListSuccessResponse):
    data: List[UnlockModel]


unlocks_namespace.schema_model(
    "UnlockDetailedSuccessResponse", UnlockDetailedSuccessResponse.apidoc()
)

unlocks_namespace.schema_model(
    "UnlockListSuccessResponse", UnlockListSuccessResponse.apidoc()
)


@unlocks_namespace.route("")
class UnlockList(Resource):
    @admins_only
    @unlocks_namespace.doc(
        description="Endpoint to get unlock objects in bulk",
        responses={
            200: ("Success", "UnlockListSuccessResponse"),
            400: (
                "An error occured processing the provided or stored data",
                "APISimpleErrorResponse",
            ),
        },
    )
    @validate_args(
        {
            "user_id": (int, None),
            "team_id": (int, None),
            "target": (int, None),
            "type": (str, None),
            "q": (str, None),
            "field": (
                RawEnum(
                    "UnlockFields", {"target": "target", "type": "type", "ip": "ip"}
                ),
                None,
            ),
            "ip": (str, None),
        },
        location="query",
    )
    def get(self, query_args):
        q = query_args.pop("q", None)
        field = str(query_args.pop("field", None))
        filters = build_model_filters(model=Unlocks, query=q, field=field)

        unlocks = Unlocks.query.filter_by(**query_args).filter(*filters).all()
        schema = UnlockSchema()
        response = schema.dump(unlocks)

        if response.errors:
            return {"success": False, "errors": response.errors}, 400

        return {"success": True, "data": response.data}

    @during_ctf_time_only
    @check_challenge_visibility
    @require_verified_emails
    @authed_only
    @unlocks_namespace.doc(
        description="Endpoint to create an unlock object. Used to unlock hints.",
        responses={
            200: ("Success", "UnlockDetailedSuccessResponse"),
            400: (
                "An error occured processing the provided or stored data",
                "APISimpleErrorResponse",
            ),
        },
    )
    def post(self):
        req = request.get_json()
        if not isinstance(req, dict) or "type" not in req or "target" not in req:
            return (
                {
                    "success": False,
                    "errors": {"target": "Missing target or type"},
                },
                400,
            )

        user = get_current_user()

        # TODO: Convert this into a re-useable decorator
        if is_teams_mode() and user.team_id is None:
            abort(403)

        target_type = req["type"]

        req["user_id"] = user.id
        req["team_id"] = user.team_id

        Model = get_class_by_tablename(target_type)
        if Model is None:
            return (
                {
                    "success": False,
                    "errors": {"type": "Unknown target type"},
                },
                400,
            )
        target = Model.query.filter_by(id=req["target"]).first_or_404()
        challenge = getattr(target, "challenge", None)

        if not is_admin() and challenge is not None:
            if challenge.state in ("hidden", "locked"):
                abort(404)

            if not can_access_challenge(challenge, user):
                abort(404)

            if challenge.requirements:
                requirements = challenge.requirements.get("prerequisites", [])
                all_challenge_ids = {
                    c.id for c in Challenges.query.with_entities(Challenges.id).all()
                }
                prereqs = set(requirements).intersection(all_challenge_ids)
                if not get_solve_ids_for_user_id(user_id=user.id) >= prereqs:
                    abort(403)

        # TODO Tandav 4.0 We should implement this with Redlock instead of SETNX
        # Lock unlocks per account so only one unlock is processed at a time
        # cache.add is SETNX, it only succeeds when the key is absent
        # The lock can be released by timeout or by the finally block
        lock_key = f"unlock_lock_{user.account_id}"
        if not cache.add(lock_key, 1, timeout=30):
            return (
                {
                    "success": False,
                    "errors": {
                        "target": "Another unlock is already being processed. Try again shortly."
                    },
                },
                403,
            )

        try:
            # End the current transaction so the checks below see unlocks and awards previously committed
            db.session.commit()

            if target_type == "hints":
                if not is_admin() and target.prerequisites:
                    unlock_ids = {
                        u.target
                        for u in HintUnlocks.query.filter_by(
                            account_id=user.account_id
                        ).all()
                    }
                    all_hint_ids = {
                        h.id for h in Hints.query.with_entities(Hints.id).all()
                    }
                    prereqs = set(target.prerequisites).intersection(all_hint_ids)
                    if not unlock_ids >= prereqs:
                        abort(403)

                # We should use the team's score if in teams mode
                # user.account gives the appropriate account based on team mode
                # Use get_score with admin to get the account's full score value
                if target.cost > user.account.get_score(admin=True):
                    return (
                        {
                            "success": False,
                            "errors": {
                                "score": "You do not have enough points to unlock this hint"
                            },
                        },
                        400,
                    )

                schema = UnlockSchema()
                response = schema.load(req, session=db.session)

                if response.errors:
                    return {"success": False, "errors": response.errors}, 400

                response.data.ip = get_ip(req=request)

                # Search for an existing unlock that matches the target and type
                # And matches either the requesting user id or the requesting team id
                existing = Unlocks.query.filter(
                    Unlocks.target == req["target"],
                    Unlocks.type == req["type"],
                    Unlocks.account_id == user.account_id,
                ).first()
                if existing:
                    return (
                        {
                            "success": False,
                            "errors": {"target": "You've already unlocked this target"},
                        },
                        400,
                    )

                db.session.add(response.data)

                award_schema = AwardSchema()
                award = {
                    "user_id": user.id,
                    "team_id": user.team_id,
                    "name": target.name,
                    "description": target.description,
                    "value": (-target.cost),
                    "category": target.category,
                }

                award = award_schema.load(award)
                db.session.add(award.data)
                db.session.commit()
                clear_standings()

                response = schema.dump(response.data)

                return {"success": True, "data": response.data}
            elif target_type == "solutions":
                if not is_admin():
                    if target.state == "visible":
                        pass
                    elif target.state == "solved":
                        if (
                            challenge is None
                            or challenge.id
                            not in get_solve_ids_for_user_id(user_id=user.id)
                        ):
                            # We return 403 here because technically the unlock is not allowed
                            # because the user hasn't solved the challenge not because the challenge doesn't exist
                            abort(403)
                    else:
                        abort(404)

                schema = UnlockSchema()
                response = schema.load(req, session=db.session)

                if response.errors:
                    return {"success": False, "errors": response.errors}, 400

                response.data.ip = get_ip(req=request)

                # Search for an existing unlock that matches the target and type
                # And matches either the requesting user id or the requesting team id
                existing = Unlocks.query.filter(
                    Unlocks.target == req["target"],
                    Unlocks.type == req["type"],
                    Unlocks.account_id == user.account_id,
                ).first()
                if existing:
                    return (
                        {
                            "success": False,
                            "errors": {"target": "You've already unlocked this target"},
                        },
                        400,
                    )

                db.session.add(response.data)
                db.session.commit()

                response = schema.dump(response.data)

                return {"success": True, "data": response.data}
            else:
                return (
                    {
                        "success": False,
                        "errors": {"type": "Unknown target type"},
                    },
                    400,
                )
        finally:
            cache.delete(lock_key)
