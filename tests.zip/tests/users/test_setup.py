#!/usr/bin/env python
# -*- coding: utf-8 -*-

from Tandav.utils.dates import ctf_started
from tests.helpers import create_tandav, destroy_tandav, gen_user


def test_tandav_setup_redirect():
    """Test that a fresh Tandav instance redirects to /setup"""
    app = create_tandav(setup=False)
    with app.app_context():
        with app.test_client() as client:
            r = client.get("/users")
            assert r.status_code == 302
            assert r.location == "/setup"

            # Files in /themes load properly
            r = client.get("/themes/core/static/manifest.json")
            r = client.get("/themes/core/static/img/favicon.ico")
            assert r.status_code == 200
    destroy_tandav(app)


def test_tandav_setup_verification():
    app = create_tandav(setup=False)
    with app.app_context():
        with app.test_client() as client:
            r = client.get("/setup")
            assert r.status_code == 200
            assert 'value="Tandav"' in r.get_data(as_text=True)

            with client.session_transaction() as sess:
                data = {
                    "ctf_name": "Tandav",
                    "ctf_description": "National Level CTF",
                    "name": "test",
                    "email": "test@examplectf.com",
                    "password": "",
                    "user_mode": "users",
                    "nonce": sess.get("nonce"),
                }
            r = client.post("/setup", data=data)
            assert "longer password" in r.get_data(as_text=True)

            gen_user(app.db, name="test", email="test@examplectf.com")

            data["password"] = "password"
            r = client.post("/setup", data=data)
            resp = r.get_data(as_text=True)
            assert "email has already been used" in resp
            assert "name is already taken" in resp

            data["name"] = "admin"
            data["email"] = "admin@examplectf.com"
            r = client.post("/setup", data=data)
            assert r.status_code == 302
            assert r.location == "/"
            assert ctf_started() is True

            r = client.get(r.location)
            assert r.status_code == 200
            assert "Tandav — National Level CTF" in r.get_data(as_text=True)
            assert "ENTER" in r.get_data(as_text=True)
            assert "tandav.io" not in r.get_data(as_text=True)

            r = client.get("/challenges")
            assert r.status_code == 200
            assert "Tandav has not started yet" not in r.get_data(as_text=True)
    destroy_tandav(app)
