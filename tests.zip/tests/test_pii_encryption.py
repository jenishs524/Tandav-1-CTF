import base64
import os

import pytest
from sqlalchemy.exc import StatementError

from Tandav.models import Teams, Users, db
from Tandav.utils.crypto import pii_search_index
from Tandav.schemas.users import UserSchema
from Tandav.schemas.teams import TeamSchema
from tests.helpers import create_tandav, destroy_tandav


def _set_pii_keys():
    os.environ["PII_ENCRYPTION_KEY"] = base64.b64encode(os.urandom(32)).decode("ascii")
    os.environ["PII_SEARCH_KEY"] = base64.b64encode(os.urandom(32)).decode("ascii")


def test_database_pii_write_is_ciphertext_and_read_is_plaintext():
    _set_pii_keys()
    app = create_tandav()
    try:
        with app.app_context():
            user = Users(
                name="pii-user",
                email="pii@example.com",
                website="https://example.com",
                affiliation="Example Org",
                country="US",
            )
            db.session.add(user)
            db.session.commit()

            row = db.session.execute(
                "SELECT website, affiliation, country FROM users WHERE id=:id",
                {"id": user.id},
            ).first()
            assert all(str(value).startswith("v1:") for value in row)

            loaded = Users.query.filter_by(id=user.id).one()
            assert loaded.website == "https://example.com"
            assert loaded.affiliation == "Example Org"
            assert loaded.country == "US"
            assert loaded.email_hmac == pii_search_index("pii@example.com")
    finally:
        os.environ.pop("PII_ENCRYPTION_KEY", None)
        os.environ.pop("PII_SEARCH_KEY", None)
        destroy_tandav(app)


def test_database_pii_tamper_is_rejected():
    _set_pii_keys()
    app = create_tandav()
    try:
        with app.app_context():
            user = Users(
                name="tamper-user",
                email="tamper@example.com",
                affiliation="Sensitive Org",
            )
            db.session.add(user)
            db.session.commit()

            db.session.execute(
                "UPDATE users SET affiliation=:value WHERE id=:id",
                {"value": "v1:" + base64.b64encode(os.urandom(28)).decode("ascii"), "id": user.id},
            )
            db.session.commit()

            with pytest.raises((RuntimeError, StatementError)):
                Users.query.filter_by(id=user.id).one()
    finally:
        os.environ.pop("PII_ENCRYPTION_KEY", None)
        os.environ.pop("PII_SEARCH_KEY", None)
        destroy_tandav(app)


def test_database_pii_invalid_key_and_rotation():
    _set_pii_keys()
    first_key = os.environ["PII_ENCRYPTION_KEY"]
    app = create_tandav()
    try:
        with app.app_context():
            user = Users(
                name="rotation-user",
                email="rotation@example.com",
                country="US",
            )
            db.session.add(user)
            db.session.commit()

            os.environ["PII_ENCRYPTION_KEY"] = base64.b64encode(os.urandom(32)).decode("ascii")
            os.environ["PII_ENCRYPTION_KEY_PREVIOUS"] = first_key
            loaded = Users.query.filter_by(id=user.id).one()
            assert loaded.country == "US"

            os.environ.pop("PII_ENCRYPTION_KEY_PREVIOUS")
            os.environ["PII_ENCRYPTION_KEY"] = base64.b64encode(os.urandom(32)).decode("ascii")
            with pytest.raises(RuntimeError):
                Users.query.filter_by(id=user.id).one()
    finally:
        os.environ.pop("PII_ENCRYPTION_KEY", None)
        os.environ.pop("PII_ENCRYPTION_KEY_PREVIOUS", None)
        os.environ.pop("PII_SEARCH_KEY", None)
        destroy_tandav(app)


def test_team_pii_database_write_and_search_index():
    _set_pii_keys()
    app = create_tandav()
    try:
        with app.app_context():
            team = Teams(
                name="pii-team",
                email="team@example.com",
                website="https://team.example.com",
                affiliation="Team Org",
            )
            db.session.add(team)
            db.session.commit()

            row = db.session.execute(
                "SELECT website, affiliation FROM teams WHERE id=:id",
                {"id": team.id},
            ).first()
            assert all(str(value).startswith("v1:") for value in row)

            loaded = Teams.query.filter_by(email_hmac=pii_search_index("team@example.com")).one()
            assert loaded.website == "https://team.example.com"
            assert loaded.affiliation == "Team Org"
    finally:
        os.environ.pop("PII_ENCRYPTION_KEY", None)
        os.environ.pop("PII_SEARCH_KEY", None)
        destroy_tandav(app)


def test_legacy_plaintext_record_migration_recovery():
    _set_pii_keys()
    app = create_tandav()
    try:
        with app.app_context():
            user = Users(name="legacy-user", email="legacy@example.com")
            db.session.add(user)
            db.session.commit()

            db.session.execute(
                "UPDATE users SET country=:value WHERE id=:id",
                {"value": "US", "id": user.id},
            )
            db.session.commit()
            assert Users.query.filter_by(id=user.id).one().country == "US"

            Users.query.filter_by(id=user.id).update(
                {"country": "US"}, synchronize_session=False
            )
            db.session.commit()

            row = db.session.execute(
                "SELECT country FROM users WHERE id=:id",
                {"id": user.id},
            ).first()
            assert str(row[0]).startswith("v1:")
            assert Users.query.filter_by(id=user.id).one().country == "US"
    finally:
        os.environ.pop("PII_ENCRYPTION_KEY", None)
        os.environ.pop("PII_SEARCH_KEY", None)
        destroy_tandav(app)


def test_public_profile_serialization_excludes_sensitive_pii():
    _set_pii_keys()
    app = create_tandav()
    try:
        with app.app_context():
            user = Users(
                name="public-user",
                email="private@example.com",
                affiliation="Private Org",
                country="US",
                website="https://public.example.com",
            )
            team = Teams(
                name="public-team",
                email="private-team@example.com",
                affiliation="Private Team Org",
                country="US",
            )
            db.session.add_all([user, team])
            db.session.commit()

            public_user = UserSchema(view="user").dump(user).data
            public_team = TeamSchema(view="user").dump(team).data
            assert "email" not in public_user
            assert "affiliation" not in public_user
            assert "country" not in public_user
            assert "email" not in public_team
            assert "affiliation" not in public_team
            assert "country" not in public_team
    finally:
        os.environ.pop("PII_ENCRYPTION_KEY", None)
        os.environ.pop("PII_SEARCH_KEY", None)
        destroy_tandav(app)


def test_invalid_key_rejected_on_database_write():
    app = create_tandav()
    try:
        with app.app_context():
            os.environ["PII_ENCRYPTION_KEY"] = "not-base64"
            with pytest.raises((RuntimeError, StatementError)):
                user = Users(
                    name="invalid-write-user",
                    email="invalid-write@example.com",
                    affiliation="Sensitive Org",
                )
                db.session.add(user)
                db.session.commit()
            db.session.rollback()
    finally:
        os.environ.pop("PII_ENCRYPTION_KEY", None)
        os.environ.pop("PII_SEARCH_KEY", None)
        destroy_tandav(app)
