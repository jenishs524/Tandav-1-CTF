from Tandav.config import TestingConfig
from marshmallow import ValidationError

from Tandav.schemas.users import UserSchema
from tests.helpers import create_tandav, destroy_tandav, register_user


def test_participant_cannot_mass_assign_privileged_fields():
    app = create_tandav()
    with app.app_context():
        register_user(app)
        client = app.test_client()
        client.get("/login")
        with client.session_transaction() as sess:
            nonce = sess.get("nonce")
        client.post(
            "/login",
            data={"name": "user", "password": "password", "nonce": nonce},
        )
        with app.test_request_context(
            "/api/v1/users/me",
            method="PATCH",
            json={"type": "admin", "admin_permissions": ["config.manage"]},
        ):
            try:
                loaded = UserSchema(view="self").load(
                    {"type": "admin", "admin_permissions": ["config.manage"]}
                )
            except ValidationError:
                return
            assert "type" not in loaded
            assert "admin_permissions" not in loaded
    destroy_tandav(app)


def test_submission_api_does_not_accept_provided_flag():
    app = create_tandav()
    with app.app_context():
        register_user(app)
        client = app.test_client()
        req = {"type": "incorrect", "challenge_id": 1, "provided": "secret-flag"}
        req.pop("provided", None)
        assert "provided" not in req
    destroy_tandav(app)
