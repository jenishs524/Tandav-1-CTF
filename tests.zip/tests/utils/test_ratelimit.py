from tests.helpers import create_tandav, destroy_tandav, register_user
from unittest.mock import patch

from Tandav.utils.decorators import ratelimit
from flask import Flask


def test_ratelimit_on_auth():
    """Test that ratelimiting function works properly"""
    app = create_tandav()
    with app.app_context():
        register_user(app)
        with app.test_client() as client:
            r = client.get("/login")
            with client.session_transaction() as sess:
                data = {
                    "name": "user",
                    "password": "wrong_password",
                    "nonce": sess.get("nonce"),
                }
            for _ in range(10):
                r = client.post("/login", data=data)
                assert r.status_code == 200

            for _ in range(5):
                r = client.post("/login", data=data)
                assert r.status_code == 429
    destroy_tandav(app)


def test_redis_limiter_failure_fails_closed():
    app = Flask(__name__)
    app.config.update(
        CACHE_TYPE="redis",
        RATELIMIT_DISABLE=False,
        TRUSTED_PROXIES=["^127\\.0\\.0\\.1$", "^::1$"],
    )

    @app.route("/limited", methods=["POST"])
    @ratelimit(method="POST", limit=1, interval=60, key_prefix="test")
    def limited():
        return "ok", 200

    with patch("Tandav.utils.decorators.cache.inc", side_effect=RuntimeError("redis unavailable")):
        with app.test_client() as client:
            response = client.post("/limited")
            assert response.status_code == 503
