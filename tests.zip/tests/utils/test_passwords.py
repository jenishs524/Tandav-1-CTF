from Tandav.utils.crypto import hash_password, sha256, verify_password
import base64
import os

from Tandav.utils.crypto import decrypt_sensitive, encrypt_sensitive
from Tandav.utils.security.mfa import (
    decrypt_secret,
    encrypt_secret,
    generate_recovery_codes,
    generate_totp_secret,
    hash_recovery_code,
    verify_totp,
)


def test_hash_password():
    assert hash_password("asdf").startswith("$argon2id$")


def test_verify_password():
    assert verify_password(
        "asdf",
        "$bcrypt-sha256$2b,12$I0CNXRkGD2Bi/lbC4vZ7Y.$1WoilsadKpOjXa/be9x3dyu7p.mslZ6",
    )


def test_sha256():
    assert (
        sha256("asdf")
        == "f0e4c2f76c58916ec258f246851bea091d14d4247a2fc3e18694461b1816e13b"
    )


def test_sensitive_aesgcm_round_trip_and_rotation_prefix():
    os.environ["PII_ENCRYPTION_KEY"] = base64.b64encode(os.urandom(32)).decode("ascii")
    encrypted = encrypt_sensitive("participant@example.com")
    assert encrypted.startswith("v1:")
    assert decrypt_sensitive(encrypted) == "participant@example.com"
    os.environ.pop("PII_ENCRYPTION_KEY")


def test_mfa_secret_encryption_totp_and_recovery_codes():
    os.environ["MFA_ENCRYPTION_KEY"] = base64.b64encode(os.urandom(32)).decode("ascii")
    secret = generate_totp_secret()
    encrypted = encrypt_secret(secret)
    assert decrypt_secret(encrypted) == secret
    codes = generate_recovery_codes(2)
    assert len(set(hash_recovery_code(code) for code in codes)) == 2
    assert len(secret) >= 32
    assert verify_totp(secret, "not-a-code") is False
    os.environ.pop("MFA_ENCRYPTION_KEY")


def test_sensitive_aesgcm_previous_key_rotation():
    first_key = os.urandom(32)
    os.environ["PII_ENCRYPTION_KEY"] = base64.b64encode(first_key).decode("ascii")
    encrypted = encrypt_sensitive("rotation-test")
    second_key = os.urandom(32)
    os.environ["PII_ENCRYPTION_KEY"] = base64.b64encode(second_key).decode("ascii")
    os.environ["PII_ENCRYPTION_KEY_PREVIOUS"] = base64.b64encode(first_key).decode("ascii")
    assert decrypt_sensitive(encrypted) == "rotation-test"
    os.environ.pop("PII_ENCRYPTION_KEY")
    os.environ.pop("PII_ENCRYPTION_KEY_PREVIOUS")
